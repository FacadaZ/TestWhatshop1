export default {
  widgets: [
    {
      name: "netlify",
      options: {
        title: "My Netlify deploys",
        sites: [
          {
            title: "WhatShop Web",
            apiId: "ec6f1c1c-d712-4bf6-9f44-4aac208d62fa",
            buildHookId: "5fca137b407416cb3913de43",
            name: "whatshop",
          },
        ],
      },
    },
  ],
};
