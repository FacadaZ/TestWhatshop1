import Entrega from "./entrega";

export default Entrega;
